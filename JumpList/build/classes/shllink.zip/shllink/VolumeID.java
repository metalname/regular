/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shllink;

import CBF.file.FileBuffer;
import java.nio.ByteBuffer;

/**
 *
 * @author heuvelc
 */
public class VolumeID {
    
    private int base;
    private int volumeIDSize;
    private int driveType;
    private int driveSerialNumber;
    private int volumeLabelOffset;
    private int volumeLabelOffsetUnicode;
    private String volumeLabel;
    
    public VolumeID() {
        
    }
    
    public void load(FileBuffer buffer) {
        base = buffer.getPosition();
        volumeIDSize = buffer.getInt();
        driveType = buffer.getInt();
        driveSerialNumber = buffer.getInt();
        volumeLabelOffset = buffer.getInt();
        // if volumeLabelOffset is 0x14 then volume label is Unicode
        if (volumeLabelOffset == 0x14) {
            volumeLabelOffset = buffer.getInt();
            readLabelUnicode(buffer);
        } else {
            readLabelAscii(buffer);
        }
    }
    
    protected void readLabelUnicode(FileBuffer buffer) {
        buffer.seek(base + volumeLabelOffsetUnicode);
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < volumeIDSize - 24) {
            char c = buffer.getChar();
            if (c != 0) {
                sb.append(c);
                i += 2;
            } else {
                break;
            }
        }
        volumeLabel = sb.toString();
    }
    
    protected void readLabelAscii(FileBuffer buffer) {
        buffer.seek(base + volumeLabelOffset);
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < volumeIDSize - 16) {
            byte b = buffer.get();
            if (b != 0) {
                sb.append((char) b);
                i++;
            } else {
                break;
            }
        }
        volumeLabel = sb.toString();        
    }
}
