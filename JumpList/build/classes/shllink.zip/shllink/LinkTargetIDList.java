/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shllink;

import CBF.file.FileBuffer;
import java.util.ArrayList;
import utils.HexFormat;

/**
 *
 * @author heuvelc
 */
public class LinkTargetIDList {

    private short size;
    private final ArrayList<ItemID> items = new ArrayList<>();

    protected class ItemID {

        protected short size;
        byte[] data;

        public ItemID(short size, byte[] data) {
            this.size = size;
            this.data = data;
        }

        public short getSize() {
            return (size);
        }

        public byte[] getData() {
            return (data);
        }
    }

    public LinkTargetIDList() {

    }

    public void load(FileBuffer buffer) {

        size = buffer.getShort();
        readItemIDs(buffer);

    }

    protected void readItemIDs(FileBuffer buffer) {

        int pos = 0;
        short sz = 0;
        do {
            sz = buffer.getShort();
            if (sz > 2) {
                byte[] b = new byte[sz - 2];
                buffer.get(b);
                ItemID itemID = new ItemID(sz, b);
                items.add(itemID);
            }
            pos += sz;
        } while ((pos < size) && (sz != 0));
    }

    public String dump() {
        StringBuilder sb = new StringBuilder();
        sb.append("Link Target ID List Size: ").append(HexFormat.numToHex(size)).append("\n");
        for (ItemID itemID : items) {
            sb.append("Item ID Size: ").append(HexFormat.numToHex(itemID.getSize()))
                    .append(", Data: ").append(dataToString(itemID.getData())).append("\n");
        }
        return (sb.toString());
    }
    
    protected String dataToString(byte[] data) {
        StringBuilder sb = new StringBuilder();
        for (byte b: data) {
            if (sb.length() > 0) {
                sb.append(" ");
            }
            sb.append(HexFormat.numToHex(b));
        }
        return(sb.toString());
    }
}
