/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shllink;

import CBF.file.FileBuffer;

/**
 *
 * @author HeuvelC
 */
public class ShlLink {
    
    private LnkHeader lnkHeader;
    private LinkTargetIDList linkTargetIDList;
    private LinkInfo linkInfo;
    private final FileBuffer buffer;
    private final String filename;
    
    public ShlLink(String filename, FileBuffer buffer) {
        this.filename = filename;
        this.buffer = buffer;
    }
    
    public void load (FileBuffer buffer) {
        buffer.seek(0);
        lnkHeader = new LnkHeader();
        lnkHeader.load(buffer);
        buffer.seek(lnkHeader.size());
        if (lnkHeader.hasLinkFlag(LinkAttrFlags.LF_HasLinkTargetIDList)) {
            linkTargetIDList = new LinkTargetIDList();
            linkTargetIDList.load(buffer);            
        }
        if (lnkHeader.hasLinkFlag(LinkAttrFlags.LF_HasLinkInfo)) {
            linkInfo = new LinkInfo();
            linkInfo.load(buffer);
        }
    }
    
    public LnkHeader getHeader() {
        return(lnkHeader);
    }
    
    public String getName() {
        return(filename);
    }
    
    public FileBuffer getBuffer() {
        return(buffer);
    }
    
}
