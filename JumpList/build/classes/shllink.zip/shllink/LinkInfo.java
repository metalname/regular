/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shllink;

import CBF.file.FileBuffer;
import java.nio.ByteBuffer;

/**
 *
 * @author heuvelc
 */
public class LinkInfo {

    private int size;
    private int headerSize;
    private int linkInfoFlags;
    private int volumeIDOffset;
    private int localBasePathOffset;
    private int commonNetworkRelativeLinkOffset;
    private int commonPathSuffixOffset;
    private int localBasePathOffsetUnicode;
    private int commonPathSuffixOffsetUnicode;
    private String localBasePath;
    private String commonPathSuffix;
    private String localBasePathUnicode;
    private String commonPathSuxxifUnicode;

    private final VolumeID volumeID = new VolumeID();

    private static final int F_VolumeIDAndLocalBasePath = 0b01;
    private static final int F_CommonNetworkRelativeLinkAndPath = 0b10;

    public LinkInfo() {

    }

    public void load(FileBuffer buffer) {
        size = buffer.getInt();
        headerSize = buffer.getInt();
        linkInfoFlags = buffer.getInt();
        volumeIDOffset = buffer.getInt();
        localBasePathOffset = buffer.getInt();
        commonNetworkRelativeLinkOffset = buffer.getInt();
        commonPathSuffixOffset = buffer.getInt();
        // localBasePathOffsetUnicode is only present if VolumeIDAndLocalBasePath flag is set and linkInfoHeaderSize >= 0x24
        if (hasFlag(F_VolumeIDAndLocalBasePath) && headerSize >= 0x24) {
            localBasePathOffsetUnicode = buffer.getInt();
        }
        // commonPathSuffixOffsetUnicode is only present if linkInfoHeaderSize >= 0x24
        if (headerSize >= 0x24) {
            commonPathSuffixOffsetUnicode = buffer.getInt();
        }
        if (volumeIDOffset > 0) {
            volumeID.load(buffer);
        }
        if (hasFlag(F_VolumeIDAndLocalBasePath)) {
            localBasePath = readAsciiString(buffer);
        }
        if (hasFlag(F_CommonNetworkRelativeLinkAndPath)) {
            //System.out.println("Common network relative link not implemented!");
            //System.exit(-1);
            // stub - skip past section
            int i = buffer.getInt();
            buffer.seek(buffer.getPosition() + i - 4);
        }
        commonPathSuffix = readAsciiString(buffer);
        if (localBasePathOffsetUnicode > 0) {
            localBasePathUnicode = readUnicodeString(buffer);
        }
        if (commonPathSuffixOffsetUnicode > 0) {
            commonPathSuxxifUnicode = readUnicodeString(buffer);
        }
    }

    protected boolean hasFlag(int flag) {
        return ((linkInfoFlags & flag) != 0);
    }

    protected String readAsciiString(FileBuffer buffer) {
        int offset = 0;
        StringBuilder sb = new StringBuilder();
        while (offset < size) {
            byte b = buffer.get();
            if (b != 0) {
                sb.append((char) b);
                offset++;
            } else {
                break;
            }
        }
        return (sb.toString());
    }

    protected String readUnicodeString(FileBuffer buffer) {
        int offset = 0;
        StringBuilder sb = new StringBuilder();
        while (offset < size) {
            char c = buffer.getChar();
            if (c != 0) {
                sb.append(c);
                offset++;
            } else {
                break;
            }
        }
        return (sb.toString());
    }

}
