/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shllink;

import CBF.file.FileBuffer;
import utils.HexFormat;
import utils.WinDate;

/**
 *
 * @author HeuvelC
 */
public class LnkHeader {
    
    private int hdrSize;
    private final byte[] linkCLSID = new byte[16];
    private int linkFlags;
    private int fileAttributes;
    private long ctime;
    private long atime;
    private long wtime;
    private int fileSize;
    private int iconIndex;
    private int showCommand;
    private short hotKey;
    
    private static final int expSz = 0x4c;
    
    public enum flags {
        
    }
    
    public LnkHeader() {
        
    }
    
    public int size() {
        return(hdrSize);
    }
    
    public boolean load(FileBuffer buffer) {
        hdrSize = buffer.getInt();
        if (hdrSize != expSz) {
            return(false);
        }
        buffer.get(linkCLSID);
        linkFlags = buffer.getInt();
        fileAttributes = buffer.getInt();
        ctime = buffer.getLong();
        atime = buffer.getLong();
        wtime = buffer.getLong();
        fileSize = buffer.getInt();
        iconIndex = buffer.getInt();
        showCommand = buffer.getInt();
        hotKey = buffer.getShort();
        return(true);
    }
    
    protected String linkAttrString() {
         int mask = 1;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < LinkAttrFlags.values().length; i++) {
            if ((linkFlags & mask) != 0) {
                if (sb.length() > 0) {
                    sb.append(" | ");
                }
                sb.append(LinkAttrFlags.values()[i].toString());
            }
            mask *= 2;
        }
        return(sb.toString());        
    }
        
    protected String fileAttrString() {
        int mask = 1;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < FileAttrFlags.values().length; i++) {
            if ((fileAttributes & mask) != 0) {
                if (sb.length() > 0) {
                    sb.append(" | ");
                }
                sb.append(FileAttrFlags.values()[i].toString());
            }
            mask *= 2;
        }
        return(sb.toString());        
    }
    
    public boolean hasLinkFlag(LinkAttrFlags linkAttrFlag) {
        int mask = 1 << linkAttrFlag.ordinal();
        return((linkFlags & mask) != 0);
    }
    
    public String dump() {
        StringBuilder sb = new StringBuilder();
        sb.append("Header Size: ").append(HexFormat.numToHex(hdrSize)).append("\n");
        sb.append("Link Attributes: ").append(linkAttrString()).append("\n");
        sb.append("File Attributes: ").append(fileAttrString()).append("\n");
        sb.append("Creation Time: ").append(WinDate.filetimeToDate(ctime)).append("\n");
        sb.append("Access Time: ").append(WinDate.filetimeToDate(atime)).append("\n");
        sb.append("Write Time: ").append(WinDate.filetimeToDate(wtime)).append("\n");
        sb.append("File Size: ").append(HexFormat.numToHex(fileSize)).append("\n");
        sb.append("Icon Index: ").append(HexFormat.numToHex(iconIndex)).append("\n");
        sb.append("Show Command: ").append(HexFormat.numToHex(showCommand)).append("\n");
        sb.append("HotKey: ").append(HexFormat.numToHex(hotKey)).append("\n");
        return(sb.toString());
    }
    
}
