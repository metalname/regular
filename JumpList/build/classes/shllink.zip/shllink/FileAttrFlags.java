/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shllink;

/**
 *
 * @author HeuvelC
 */
public enum FileAttrFlags {
    FILE_ATTRIBUTE_READONLY, //The file or directory is read-only. For a file, if this bit is set, applications can read the file but cannot write to it or delete it. For a directory, if this bit is set, applications cannot delete the directory.
    FILE_ATTRIBUTE_HIDDEN, //The file or directory is hidden. If this bit is set, the file or folder is not included in an ordinary directory listing.
    FILE_ATTRIBUTE_SYSTEM, //The file or directory is part of the operating system or is used exclusively by the operating system.
    Reserved1, //A bit that MUST be zero.
    FILE_ATTRIBUTE_DIRECTORY, //The link target is a directory instead of a file.
    FILE_ATTRIBUTE_ARCHIVE, //The file or directory is an archive file. Applications use this flag to mark files for backup or removal.
    Reserved2, //A bit that MUST be zero.
    FILE_ATTRIBUTE_NORMAL, //The file or directory has no other flags set. If this bit is 1, all other bits in this structure MUST be clear.
    FILE_ATTRIBUTE_TEMPORARY, //The file is being used for temporary storage.
    FILE_ATTRIBUTE_SPARSE_FILE, //The file is a sparse file.
    FILE_ATTRIBUTE_REPARSE_POINT, //The file or directory has an associated reparse point.
    FILE_ATTRIBUTE_COMPRESSED, //The file or directory is compressed. For a file, this means that all data in the file is compressed. For a directory, this means that compression is the default for newly created files and subdirectories.
    FILE_ATTRIBUTE_OFFLINE, //The data of the file is not immediately available.
    FILE_ATTRIBUTE_NOT_CONTENT_INDEXED, //The contents of the file need to be indexed.
    FILE_ATTRIBUTE_ENCRYPTED; //The file or directory is encrypted. For a file, this means that all data in the file is encrypted. For a directory, this means that encryption is the default for newly created files and subdirectories.
}
