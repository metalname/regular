/******************************************************************************
 * Input helpers are Swing components designed for editing different data types
 */
package InputHelpers;

import javax.swing.JPanel;

/**
 *
 * Base class for input helpers
 */
public abstract class AbstractInput extends JPanel {

}
