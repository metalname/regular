/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BinBuffer.Var;

/**
 *
 * @author 0
 */
public enum VarType {
    T_BYTE, T_SHORT, T_INT, T_CHAR, T_LONG, T_ASCIISZ, T_UNICODESZ, T_UNICODESL, T_ASCIISL, T_BARRAY, T_VARSET, T_VARARRY;
}
