/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Forms;

import java.util.ArrayList;

/**
 *
 * @author 
 */
public class TableData extends ArrayList<TableRow> {
    private static final long serialVersionUID = -8967178786550386636L;
    
}
