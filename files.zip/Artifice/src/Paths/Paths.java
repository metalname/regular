/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Paths;

/**
 *
 * @author 
 */
public class Paths {
    
    public static final String Windows = "Windows/";
    //public static final String Hives = Windows + "System32/Config/";
    public static final String Hives = Windows + "System32/config/";
    public static final String Users = "Users/";
    public static final String UsrClass = "AppData/Local/Microsoft/Windows/";
    //public static final String Inf = Windows + "/inf";
    public static final String Inf = Windows + "/INF";
}
