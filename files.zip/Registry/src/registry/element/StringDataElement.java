package registry.element;

/**
 *
 * Interface for string type elements
 */
public interface StringDataElement {
    
    public String getValueS();    
    
}
