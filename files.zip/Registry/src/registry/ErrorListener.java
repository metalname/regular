package registry;

/**
 *
 * Simple error reporting interface
 */
public interface ErrorListener {
    
    public void notify(String message);
    
}
